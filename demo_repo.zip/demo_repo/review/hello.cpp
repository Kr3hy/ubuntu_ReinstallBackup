//
// Created by kr3hy on 22-10-29.
//
#include "iostream"
#include "ros/ros.h"
//#include "opencv4/opencv2/opencv.hpp"
using namespace std;
int main()
{
    cout<<"hello"<<endl;
    return 0;
}